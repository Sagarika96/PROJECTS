package main

import "fmt"

func main() {
    fmt.Println("hello from Phu Phung - SecAD-S19")
}
