<?php
	echo "your input=" .$_GET["input"];
	//phpinfo();
?>
