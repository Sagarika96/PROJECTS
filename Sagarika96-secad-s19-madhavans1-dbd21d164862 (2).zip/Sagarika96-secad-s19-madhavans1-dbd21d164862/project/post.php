
<form action="newpost.php" method="POST" >
<textarea name="post" rows="5" cols="20" placeholder="please post!"> </textarea>
	<br>
	<input type="submit" value="Post it">
	</form>
	<a href="index.php">Go back to home</a>

<form method="get" action="viewpost.php">
    <button type="submit">View Post</button>
</form>


<a href="index.php">Home</a>


