

 <?php
$servername = "localhost";
$username = "madhavans1";
$password = "***";
$dbname = "secad_s19";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$prepared_sql = "SELECT * FROM comments";
$result = $conn->query($prepared_sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>text</th><th>user</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["owner"]."</td><td>".$row["comments"]."</td><td>".$row["postid"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?> 
