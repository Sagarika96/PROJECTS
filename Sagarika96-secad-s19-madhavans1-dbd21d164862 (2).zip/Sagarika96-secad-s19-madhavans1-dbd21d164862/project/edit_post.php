<?php 
 session_start();
  require 'database.php';
 $postid = $_REQUEST["postid"];

 echo "id is ". $postid;
 
   echo "Check post";

  //$postid = $_POST['postid'];
  $post = $_POST['updatepost'];
       
$nocsrftoken = $_POST["nocsrftoken"];
    $sessionnocsrftoken = $_SESSION["nocsrftoken"];
echo "post is ".$post;

  if (isset($postid) and isset($post)){

  if(!isset($nocsrftoken) or ($nocsrftoken!=$sessionnocsrftoken)){
       echo "Cross-site request forgery is detected!";
       die();
       }
 // echo "Prepared Statement Error";
  //echo "About to update";
  if(updatepost($postid,$post)){

        echo " Post Updated";
  }else
  echo "Post not updated";
    }

  //access the database to get the current post content of the postid you get
  //store in in $currentpost
$rand = bin2hex(openssl_random_pseudo_bytes(16));
  $_SESSION["nocsrftoken"] = $rand;
?>

<html>
      <h1>Update Your Post</h1> 
    <?php

      $postid = $_REQUEST['postid'];
  echo "Current time: " . date("Y-m-d h:i:sa");
?>         
  <form action="edit_post.php?postid=<?php echo htmlentities($postid); ?>" method="POST" class="form login">
  <br>
  <input type="hidden" name="nocsrftoken" value="<?php echo $rand;?>"/>
  <br>
  <input type="textarea" name="updatepost" required cols="2" rows="2"  title="Update post" value="<?php echo $post;?>"/>
  <br>
  <button class="button" type="submit">
  Update Post
  </button>
  </form>  </html>


