
<?php 
  require 'database.php';
 
$postid=$_REQUEST['postid'];
  function handle_post($postid){
   echo "view post";
	$postid = $_POST['postid'];
	$post = $_POST['post'];
  if (isset($id) ){
	if(show_addpost($postid))
        echo " Post Viewed";
	else
	echo "Error";
    }else{
	echo "NO POST";
	}
	}
  show_addpost();
?>
<a href="display_comments.php">View the comments</a>
<form action="comment.php?postid=<?php echo $postid; ?>;" method="POST" class="form login" >
            <br>
            <input type="hidden" name="nocsrftoken" value="<?php echo $rand; ?>" />
            your id :<input type="text" name="commenter"/><br> 
                
                 <br>
                 content: <textarea name="content" required cols="100" rows="10"  ></textarea>
                 <br>
                <button class="button" type="submit">
                  submit new comment
                </button>
          </form>
</html>