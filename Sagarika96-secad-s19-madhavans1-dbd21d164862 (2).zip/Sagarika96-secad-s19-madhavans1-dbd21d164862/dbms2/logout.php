<?php
	session_start();
	session_destroy();
?>
<p> you are logged out! </p>
<a href="form.php">Login again </a>
