var m1 = require('./module1');
console.log('m1=', +m1);
console.log('m1.a=',+m1.a);
m1.f();
