var a = 1;
module.exports.a = a;
exports.f = function(){console.log('f from module1');}
